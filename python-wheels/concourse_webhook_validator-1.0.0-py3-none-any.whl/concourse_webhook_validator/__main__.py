from concourse_webhook_validator import main

main()
